/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[28];
    char stringdata[603];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10),
QT_MOC_LITERAL(1, 11, 4),
QT_MOC_LITERAL(2, 16, 0),
QT_MOC_LITERAL(3, 17, 4),
QT_MOC_LITERAL(4, 22, 5),
QT_MOC_LITERAL(5, 28, 19),
QT_MOC_LITERAL(6, 48, 21),
QT_MOC_LITERAL(7, 70, 16),
QT_MOC_LITERAL(8, 87, 18),
QT_MOC_LITERAL(9, 106, 24),
QT_MOC_LITERAL(10, 131, 36),
QT_MOC_LITERAL(11, 168, 7),
QT_MOC_LITERAL(12, 176, 40),
QT_MOC_LITERAL(13, 217, 23),
QT_MOC_LITERAL(14, 241, 5),
QT_MOC_LITERAL(15, 247, 30),
QT_MOC_LITERAL(16, 278, 32),
QT_MOC_LITERAL(17, 311, 27),
QT_MOC_LITERAL(18, 339, 29),
QT_MOC_LITERAL(19, 369, 30),
QT_MOC_LITERAL(20, 400, 26),
QT_MOC_LITERAL(21, 427, 5),
QT_MOC_LITERAL(22, 433, 28),
QT_MOC_LITERAL(23, 462, 30),
QT_MOC_LITERAL(24, 493, 24),
QT_MOC_LITERAL(25, 518, 27),
QT_MOC_LITERAL(26, 546, 29),
QT_MOC_LITERAL(27, 576, 26)
    },
    "MainWindow\0Help\0\0Quit\0About\0"
    "EnableFileTestItems\0EnableMemoryTestItems\0"
    "BuildCommandLine\0DisplayCommandLine\0"
    "on_buttonRunTest_clicked\0"
    "on_radioButtonFileIOtestmode_toggled\0"
    "checked\0on_radioButtonMemoryOnlyTestMode_toggled\0"
    "checkBoxVerbose_changed\0state\0"
    "checkBoxAutoMemoryTest_changed\0"
    "checkBoxRandomBufferFill_changed\0"
    "checkBoxLoopForever_changed\0"
    "checkBoxTimeProfiling_changed\0"
    "checkBoxMemoryOnlyTest_changed\0"
    "lineEditBufferSize_changed\0value\0"
    "lineEditPassesNumber_changed\0"
    "lineEditAutoMemBufSize_changed\0"
    "lineEditFileSize_changed\0"
    "lineEditFilesNumber_changed\0"
    "lineEditThreadsNumber_changed\0"
    "textEditCmdLineBuf_changed"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  129,    2, 0x08 /* Private */,
       3,    0,  130,    2, 0x08 /* Private */,
       4,    0,  131,    2, 0x08 /* Private */,
       5,    0,  132,    2, 0x08 /* Private */,
       6,    0,  133,    2, 0x08 /* Private */,
       7,    0,  134,    2, 0x08 /* Private */,
       8,    0,  135,    2, 0x08 /* Private */,
       9,    0,  136,    2, 0x08 /* Private */,
      10,    1,  137,    2, 0x08 /* Private */,
      12,    1,  140,    2, 0x08 /* Private */,
      13,    1,  143,    2, 0x08 /* Private */,
      15,    1,  146,    2, 0x08 /* Private */,
      16,    1,  149,    2, 0x08 /* Private */,
      17,    1,  152,    2, 0x08 /* Private */,
      18,    1,  155,    2, 0x08 /* Private */,
      19,    1,  158,    2, 0x08 /* Private */,
      20,    1,  161,    2, 0x08 /* Private */,
      22,    1,  164,    2, 0x08 /* Private */,
      23,    1,  167,    2, 0x08 /* Private */,
      24,    1,  170,    2, 0x08 /* Private */,
      25,    1,  173,    2, 0x08 /* Private */,
      26,    1,  176,    2, 0x08 /* Private */,
      27,    0,  179,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   11,
    QMetaType::Void, QMetaType::Bool,   11,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        switch (_id) {
        case 0: _t->Help(); break;
        case 1: _t->Quit(); break;
        case 2: _t->About(); break;
        case 3: _t->EnableFileTestItems(); break;
        case 4: _t->EnableMemoryTestItems(); break;
        case 5: _t->BuildCommandLine(); break;
        case 6: _t->DisplayCommandLine(); break;
        case 7: _t->on_buttonRunTest_clicked(); break;
        case 8: _t->on_radioButtonFileIOtestmode_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 9: _t->on_radioButtonMemoryOnlyTestMode_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 10: _t->checkBoxVerbose_changed((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->checkBoxAutoMemoryTest_changed((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->checkBoxRandomBufferFill_changed((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->checkBoxLoopForever_changed((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->checkBoxTimeProfiling_changed((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->checkBoxMemoryOnlyTest_changed((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->lineEditBufferSize_changed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 17: _t->lineEditPassesNumber_changed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 18: _t->lineEditAutoMemBufSize_changed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 19: _t->lineEditFileSize_changed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 20: _t->lineEditFilesNumber_changed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 21: _t->lineEditThreadsNumber_changed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 22: _t->textEditCmdLineBuf_changed(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, 0, 0}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    if (!strcmp(_clname, "Ui::MainWindow"))
        return static_cast< Ui::MainWindow*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 23;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
